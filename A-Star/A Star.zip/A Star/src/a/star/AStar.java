/*  CMPS 420         Sec. 1          Project 1
    Wong, Yee H.     yxw0087         Submitted: 2/20/15

    Name: 8-tiles Puzzle Solver
    Problem Statement: This is a program that allows used the best-first search 
    algorithm to solve any solvable 8-tiles puzzle given the initial and goal 
    states by the user. 

    Problem Specification: When asked for initial and goal states input, the 
    program assumes that the user will enter positive integer in the range of 0 
    to 8 inclusive for the puzzle, where 0 stands for a blank tile. Same integer 
    must not be repeated in a state. Any other input out of range/type or 
    repeated input will cause the program to malfunction.
*/

package a.star;

import java.util.*;

public class AStar {

    public static void main(String[] args) {
        AStar a = new AStar();
    }

    public AStar() {

        State init, goal, X;
        init = new State();
        goal = new State();
        Vector<State> open = new Vector<State>();
        Vector<State> closed = new Vector<State>();
        Scanner sc = new Scanner(System.in);
        Boolean done = false;

        System.out.println("Enter the initial state(From left to right, up to down, one number at a time. 0 to indicate blank).");
        for (int i = 0; i < 9; i += 3) {
            System.out.print("Enter number at [" + i / 3 + "][0]:");
            init.board[i] = sc.nextInt();
            System.out.print("Enter number at [" + i / 3 + "][1]:");
            init.board[i + 1] = sc.nextInt();
            System.out.print("Enter number at [" + i / 3 + "][2]:");
            init.board[i + 2] = sc.nextInt();
        }
        System.out.println();
        System.out.println("Enter the goal state(From left to right, up to down, one number at a time. 0 to indicate blank).");
        for (int i = 0; i < 9; i += 3) {
            System.out.print("Enter number at [" + i / 3 + "][0]:");
            goal.board[i] = sc.nextInt();
            System.out.print("Enter number at [" + i / 3 + "][1]:");
            goal.board[i + 1] = sc.nextInt();
            System.out.print("Enter number at [" + i / 3 + "][2]:");
            goal.board[i + 2] = sc.nextInt();
        }
        System.out.println();
        if (!solvable(init, goal)) {
            System.out.println("Unsolvable puzzle.");
        } else {

            init.level = 0;
            open.add(init);
            //Starts of A* Algorithm
            while (!open.isEmpty() && !done) {

                X = open.firstElement();
                open.remove(0);

                if (Arrays.equals(X.board, goal.board)) {
                    returnPath(X);
                    done = true;
                } else {
                    generateChild(X, goal);
                    //Child 1
                    if (!contains(X.child1, open) && !contains(X.child1, open)) {
                        open.add(X.child1);
                    } else if (contains(X.child1, open)) {
                        if (X.level + 1 <= open.elementAt(index(X.child1, open)).level) {
                            open.remove(index(X.child1, open));
                            open.add(X.child1);
                        }
                    } else if (contains(X.child1, closed)) {
                        if (X.level + 1 <= closed.elementAt(index(X.child1, closed)).level) {
                            closed.remove(index(X.child1, closed));
                            open.add(X.child1);
                        }
                    }
                    //Child 2
                    if (!contains(X.child2, open) && !contains(X.child2, open)) {
                        open.add(X.child2);
                    } else if (contains(X.child2, open)) {
                        if (X.level + 1 <= open.elementAt(index(X.child2, open)).level) {
                            open.remove(index(X.child2, open));
                            open.add(X.child2);
                        }
                    } else if (contains(X.child2, closed)) {
                        if (X.level + 1 <= closed.elementAt(index(X.child2, closed)).level) {
                            closed.remove(index(X.child2, closed));
                            open.add(X.child2);
                        }
                    }
                    //Child 3
                    if (X.child3 != null) {
                        if (!contains(X.child3, open) && !contains(X.child3, open)) {
                            open.add(X.child3);
                        } else if (contains(X.child3, open)) {
                            if (X.level + 1 <= open.elementAt(index(X.child3, open)).level) {
                                open.remove(index(X.child3, open));
                                open.add(X.child3);
                            }
                        } else if (contains(X.child3, closed)) {
                            if (X.level + 1 <= closed.elementAt(index(X.child3, closed)).level) {
                                closed.remove(index(X.child3, closed));
                                open.add(X.child3);
                            }
                        }
                    }
                    //Child 4
                    if (X.child4 != null) {
                        if (!contains(X.child4, open) && !contains(X.child4, open)) {
                            open.add(X.child4);
                        } else if (contains(X.child4, open)) {
                            if (X.level + 1 <= open.elementAt(index(X.child4, open)).level) {
                                open.remove(index(X.child4, open));
                                open.add(X.child4);
                            }
                        } else if (contains(X.child4, closed)) {
                            if (X.level + 1 <= closed.elementAt(index(X.child4, closed)).level) {
                                closed.remove(index(X.child4, closed));
                                open.add(X.child4);
                            }
                        }
                    }
                    closed.add(X);
                    reorder(open);
                }
            }
            if (!done) {
                System.out.println("Failed.");
            }
        }
    }

    public void returnPath(State s) {

        Vector<int[]> path = new Vector<int[]>();
        path.add(s.board);
        s = s.parent;
        for (int i = s.level; i >= 0; i--) {
            path.add(s.board);
            s = s.parent;
        }
        System.out.println("State transition:");
        for (int i = path.size(); i > 0; i--) {
            for (int j = 0; j < 9; j += 3) {
                System.out.print(path.get(i - 1)[j] + " ");
                System.out.print(path.get(i - 1)[j + 1] + " ");
                System.out.println(path.get(i - 1)[j + 2]);
            }
            System.out.println();
        }
    }

    public void generateChild(State s, State goal) {

        s.child1 = new State();
        s.child1.level = s.level + 1;
        s.child1.parent = s;
        s.child2 = new State();
        s.child2.level = s.level + 1;
        s.child2.parent = s;

        if (s.board[0] == 0) {
            for (int i = 0; i < 9; i++) {
                s.child1.board[i] = s.board[i];
                s.child2.board[i] = s.board[i];
            }
            s.child1.board[0] = s.board[1];
            s.child1.board[1] = 0;
            s.child2.board[0] = s.board[3];
            s.child2.board[3] = 0;
        } else if (s.board[1] == 0) {
            s.child3 = new State();
            s.child3.level = s.level + 1;
            s.child3.parent = s;
            for (int i = 0; i < 9; i++) {
                s.child1.board[i] = s.board[i];
                s.child2.board[i] = s.board[i];
                s.child3.board[i] = s.board[i];
            }
            s.child1.board[1] = s.board[0];
            s.child1.board[0] = 0;
            s.child2.board[1] = s.board[2];
            s.child2.board[2] = 0;
            s.child3.board[1] = s.board[4];
            s.child3.board[4] = 0;
        } else if (s.board[2] == 0) {
            for (int i = 0; i < 9; i++) {
                s.child1.board[i] = s.board[i];
                s.child2.board[i] = s.board[i];
            }
            s.child1.board[2] = s.board[1];
            s.child1.board[1] = 0;
            s.child2.board[2] = s.board[5];
            s.child2.board[5] = 0;
        } else if (s.board[3] == 0) {
            s.child3 = new State();
            s.child3.level = s.level + 1;
            s.child3.parent = s;
            for (int i = 0; i < 9; i++) {
                s.child1.board[i] = s.board[i];
                s.child2.board[i] = s.board[i];
                s.child3.board[i] = s.board[i];
            }
            s.child1.board[3] = s.board[0];
            s.child1.board[0] = 0;
            s.child2.board[3] = s.board[4];
            s.child2.board[4] = 0;
            s.child3.board[3] = s.board[6];
            s.child3.board[6] = 0;
        } else if (s.board[4] == 0) {
            s.child3 = new State();
            s.child3.level = s.level + 1;
            s.child3.parent = s;
            s.child4 = new State();
            s.child4.level = s.level + 1;
            s.child4.parent = s;
            for (int i = 0; i < 9; i++) {
                s.child1.board[i] = s.board[i];
                s.child2.board[i] = s.board[i];
                s.child3.board[i] = s.board[i];
                s.child4.board[i] = s.board[i];
            }
            s.child1.board[4] = s.board[1];
            s.child1.board[1] = 0;
            s.child2.board[4] = s.board[3];
            s.child2.board[3] = 0;
            s.child3.board[4] = s.board[5];
            s.child3.board[5] = 0;
            s.child4.board[4] = s.board[7];
            s.child4.board[7] = 0;
        } else if (s.board[5] == 0) {
            s.child3 = new State();
            s.child3.level = s.level + 1;
            s.child3.parent = s;
            for (int i = 0; i < 9; i++) {
                s.child1.board[i] = s.board[i];
                s.child2.board[i] = s.board[i];
                s.child3.board[i] = s.board[i];
            }
            s.child1.board[5] = s.board[2];
            s.child1.board[2] = 0;
            s.child2.board[5] = s.board[4];
            s.child2.board[4] = 0;
            s.child3.board[5] = s.board[8];
            s.child3.board[8] = 0;
        } else if (s.board[6] == 0) {
            for (int i = 0; i < 9; i++) {
                s.child1.board[i] = s.board[i];
                s.child2.board[i] = s.board[i];
            }
            s.child1.board[6] = s.board[3];
            s.child1.board[3] = 0;
            s.child2.board[6] = s.board[7];
            s.child2.board[7] = 0;
        } else if (s.board[7] == 0) {
            s.child3 = new State();
            s.child3.level = s.level + 1;
            s.child3.parent = s;
            for (int i = 0; i < 9; i++) {
                s.child1.board[i] = s.board[i];
                s.child2.board[i] = s.board[i];
                s.child3.board[i] = s.board[i];
            }
            s.child1.board[7] = s.board[6];
            s.child1.board[6] = 0;
            s.child2.board[7] = s.board[4];
            s.child2.board[4] = 0;
            s.child3.board[7] = s.board[8];
            s.child3.board[8] = 0;
        } else if (s.board[8] == 0) {
            for (int i = 0; i < 9; i++) {
                s.child1.board[i] = s.board[i];
                s.child2.board[i] = s.board[i];
            }
            s.child1.board[8] = s.board[5];
            s.child1.board[5] = 0;
            s.child2.board[8] = s.board[7];
            s.child2.board[7] = 0;
        }

        s.child1.heuristic = s.child1.level + countOutofPlace(s.child1, goal);
        s.child2.heuristic = s.child2.level + countOutofPlace(s.child2, goal);
        if (s.child3 != null) {
            s.child3.heuristic = s.child3.level + countOutofPlace(s.child3, goal);
        }
        if (s.child4 != null) {
            s.child4.heuristic = s.child4.level + countOutofPlace(s.child4, goal);
        }
    }

    public int countOutofPlace(State s, State goal) {

        int count = 0;

        for (int i = 0; i < 9; i++) {
            if (s.board[i] != goal.board[i]) {
                count++;
            }
        }
        return count;
    }

    public boolean contains(State s, Vector<State> v) {

        for (int i = 0; i < v.size(); i++) {
            if (Arrays.equals(v.elementAt(i).board, s.board)) {
                return true;
            }
        }

        return false;
    }

    public int index(State s, Vector<State> v) {

        for (int i = 0; i < v.size(); i++) {
            if (Arrays.equals(v.elementAt(i).board, s.board)) {
                return i;
            }
        }

        return -1;
    }

    public void reorder(Vector<State> open) {

        State temp;

        if (open.size() > 0) {
            for (int i = 1; i < open.size(); i++) {
                temp = open.elementAt(i);
                int j = i;
                while (j > 0 && (open.elementAt(j - 1).heuristic > temp.heuristic)) {
                    open.set(j, open.elementAt(j - 1));
                    j--;
                }
                open.set(j, temp);
            }
        }
    }

    public Boolean solvable(State init, State goal) {

        Vector<Integer> init_vec = new Vector<Integer>();
        Vector<Integer> goal_vec = new Vector<Integer>();
        int count = 0;

        for (int i = 0; i < 9; i++) {
            if (init.board[i] != 0) {
                init_vec.add(init.board[i]);
            }
            if (goal.board[i] != 0) {
                goal_vec.add(goal.board[i]);
            }
        }
        for (int i = 0; i < 7; i++) {
            for (int j = i + 1; j < 8; j++) {
                if (goal_vec.indexOf(init_vec.elementAt(i)) > goal_vec.indexOf(init_vec.elementAt(j))) {
                    count++;
                }
            }
        }
        if (count % 2 == 0) {
            return true;
        } else {
            return false;
        }
    }
}
