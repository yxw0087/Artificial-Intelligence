/*  CMPS 420         Sec. 1          Project 1
    Wong, Yee H.     yxw0087         Submitted: 2/20/15

    Name: 8-tiles Puzzle Solver
    Problem Statement: This is a program that allows used the best-first search 
    algorithm to solve any solvable 8-tiles puzzle given the initial and goal 
    states by the user. 

    Problem Specification: When asked for initial and goal states input, the 
    program assumes that the user will enter positive integer in the range of 0 
    to 8 inclusive for the puzzle, where 0 stands for a blank tile. Same integer 
    must not be repeated in a state. Any other input out of range/type or 
    repeated input will cause the program to malfunction.
*/

package a.star;

public class State {

    int[] board = new int[9];

    int level, heuristic;

    State child1, child2, child3, child4, parent;

    public State() {

        for (int i = 0; i < 9; i++) {
            board[i] = -1;
        }

        level = heuristic = 0;

        child1 = child2 = child3 = child4 = parent = null;
    }

}