/*  CMPS 420         Sec. 1          Project 2
    Wong, Yee H.     yxw0087         Submitted: 3/18/15

    Name: CNF Solver using Genetic Algorithm
    Problem Statement: This is a program that will solve a given CNF with the 
                       Genetic Algorithm

    Problem Specification: When prompted for the CNF, user must input a valid 
                           CNF containing minimum of two to maximum of 26
                           variables. The variables can only consist of alphabets
                           'a' to 'z', case insensitive.
*/

package genetic;

import java.util.*;

public class Candidate {

    int[] bits, tempbits;
    int fitness;
    double fitnessRatio, upperRange, lowerRange;
    boolean picked;

    public Candidate() {
        bits = null;
        tempbits = null;
        fitness = 0;
        fitnessRatio = 0.0;
        upperRange = 0.0;
        lowerRange = 0.0;
        picked = false;
    }

    public Candidate(int numVar) {

        bits = new int[numVar];
        tempbits = new int[numVar];

        tempbits[0] = -1;

        Random rand = new Random();

        for (int i = 0; i < numVar; i++) {
            bits[i] = rand.nextInt(2);
        }

        fitness = 0;
        fitnessRatio = 0.0;
        upperRange = 0.0;
        lowerRange = 0.0;
        picked = false;
    }
}
