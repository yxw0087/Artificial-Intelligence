/*  CMPS 420         Sec. 1          Project 2
    Wong, Yee H.     yxw0087         Submitted: 3/18/15

    Name: CNF Solver using Genetic Algorithm
    Problem Statement: This is a program that will solve a given CNF with the 
                       Genetic Algorithm

    Problem Specification: When prompted for the CNF, user must input a valid 
                           CNF containing minimum of two to maximum of 26
                           variables. The variables can only consist of alphabets
                           'a' to 'z', case insensitive.
*/

package genetic;

import java.util.*;

public class Genetic {

    public static void main(String[] args) {
        Genetic g = new Genetic();
    }

    public Genetic() {

        String CNF;
        int numClause, numVar, size;
        int time = 0;
        int totalFitness;
        Scanner sc = new Scanner(System.in);
        Vector<Candidate> chromosomes = new Vector<Candidate>();
        Vector<Candidate> tempchromosomes = new Vector<Candidate>();
        Vector<Character> variables = new Vector<Character>();
        char[] map = new char[26];
        Boolean solution = false;
        System.out.println("Enter the CNF: ");
        CNF = sc.nextLine().toLowerCase();

        numClause = countClauses(CNF);
        numVar = countVar(CNF, map, variables);
        System.out.println("Number var: " + numVar);
        if (numVar == 0 || numClause == 0 || numVar == 1) {
            System.out.println("Enter at least 1 clause and more than 1 variable.");
            System.exit(0);
        }

        //Pupulation size is half of the numble of varaibles
        size = numVar / 2;

        //Make population size even
        if (size % 2 != 0) {
            size++;
        }

        //Create the initial population
        createInit(numVar, size, chromosomes);

        do {
            System.out.println("\nGeneration " + time);
            totalFitness = 0;
            for (int i = 0; i < chromosomes.size(); i++) {
                chromosomes.elementAt(i).fitness = checkCNF(CNF, numClause, chromosomes.elementAt(i).bits, map, variables);
                totalFitness += chromosomes.elementAt(i).fitness;
            }

            //For each chromosome, checks how many clauses are matched by its bits
            for (int i = 0; i < chromosomes.size(); i++) {
                System.out.print("Chromosome " + i + " is ");
                for (int j = 0; j < numVar; j++) {
                    System.out.print(chromosomes.elementAt(i).bits[j]);
                }
                chromosomes.elementAt(i).fitnessRatio = (double) chromosomes.elementAt(i).fitness / totalFitness;
                chromosomes.elementAt(i).upperRange = chromosomes.elementAt(i).fitnessRatio + chromosomes.elementAt(i).lowerRange;

                System.out.print(", with a fitness of " + chromosomes.elementAt(i).fitness);
                System.out.print(", a fitness ratio of " + chromosomes.elementAt(i).fitnessRatio);
                System.out.println(" and falls in the range of " + chromosomes.elementAt(i).lowerRange + " to " + chromosomes.elementAt(i).upperRange);

                if (i != (chromosomes.size() - 1)) {
                    chromosomes.elementAt(i + 1).lowerRange = chromosomes.elementAt(i).upperRange;
                }
                //If number of matched clauses equals number of clauses, solution is found
                if (chromosomes.elementAt(i).fitness == numClause) {
                    solution = true;
                    System.out.print("Solution is found at generation " + time + ", solution is: ");
                    for (int j = 0; j < numVar; j++) {
                        System.out.print(chromosomes.elementAt(i).bits[j]);
                    }
                    System.out.println();
                    System.exit(0);
                }
            }

            //Perform crossover
            crossOver(numVar, size, chromosomes);
            time++;

            //Perform mutation
            mutation(numVar, chromosomes);

        } while (!solution);
    }

    public int checkCNF(String CNF, int numClause, int[] bits, char[] map, Vector<Character> v) {

        int index;
        int count = 0;
        Boolean[] check = new Boolean[numClause];

        //Initializes check to all false
        for (int i = 0; i < numClause; i++) {
            check[i] = false;
        }

        Boolean not = false;
        Boolean done = false;

        //Start reading the CNF, and see if our chromosomes match it
        for (int i = 0; i < CNF.length(); i++) {

            switch (CNF.charAt(i)) {
                case '!':
                    //If ! is used, set 'not' to true, so that next variable read
                    //will be evaluated to its negated value
                    not = true;
                    break;
                case '*':
                    //If * is encounter, means we are moving to the next clause
                    //so set the done status of this new clause to false
                    done = false;
                    break;
                case '(':
                case ')':
                case ' ':
                case '+':
                    break;
                default:
                    //If this clause is not done yet, and one of the variables in this clause
                    //matches the bit, we say this clause is true and done
                    if (!done && not == false && bits[v.indexOf(CNF.charAt(i))] == 1) {
                        check[count++] = true;
                        done = true;
                    } else if (!done && not == true && bits[v.indexOf(CNF.charAt(i))] == 0) {
                        check[count++] = true;
                        done = true;
                    }
                    not = false;
                    break;
            }
        }

        count = 0;

        //Counts the number of true clauses after reading the CNF
        for (int i = 0; i < numClause; i++) {
            if (check[i]) {
                count++;
            }
        }
        return count;
    }

    //Count number of clauses in the CNF
    public int countClauses(String CNF) {

        int count = 0;

        for (int i = 0; i < CNF.length(); i++) {
            if (CNF.charAt(i) == '*') {
                count++;
            }
        }
        return count + 1;
    }

    //Count number of variables in the CNF
    public int countVar(String CNF, char[] map, Vector<Character> v) {

        int count = 0;
        int index;

        //Maps all the varaibles in the CNF to their corresponding index; 
        //a=0, b=1...z=25 etc.
        for (int i = 0; i < CNF.length(); i++) {

            switch (CNF.charAt(i)) {
                case '(':
                case ')':
                case '+':
                case '*':
                case ' ':
                case '!':
                    break;
                default:
                    try {
                        index = (int) CNF.charAt(i) - 97;
                        map[index] = CNF.charAt(i);
                    } catch (Exception e) {
                        System.out.println("Please use only 'a' to 'z' for variables in CNF.");
                        System.exit(0);
                    }
                    break;
            }
        }

        //Copies the mapped variables into a vector
        //At the end of this loop, vector v will have size of numVar
        for (int i = 0; i < map.length; i++) {
            if (Character.isAlphabetic(map[i])) {
                v.add(map[i]);
            }
        }

        return v.size();
    }

    public void createInit(int numVar, int size, Vector<Candidate> v) {

        Boolean duplicate;
        Candidate initial;

        for (int i = 0; i < size; i++) {
            do {
                duplicate = false;
                initial = new Candidate(numVar);
                for (int j = 0; j < v.size(); j++) {
                    if (Arrays.equals(initial.bits, v.elementAt(j).bits)) {
                        duplicate = true;
                    }
                }
            } while (duplicate);
            v.add(initial);
        }
    }

    public void crossOver(int numVar, int size, Vector<Candidate> v1) {

        String first, second, first_a, first_b, second_a, second_b;
        int breakpoint, index1, index2;
        int count = 0;
        int raps;

        //Checks if all members have fitness 0
        for (int i = 0; i < v1.size(); i++) {
            if (v1.elementAt(i).fitness == 0) {
                count++;
            }
        }

        if (count == v1.size()) {
            System.out.println("All members have fitness 0, system halting.");
            System.exit(0);
        }

        //If this population contains member with fitness 0, do not cross over with it
        raps = size / 2 - Math.round((float) count / 2);

        for (int i = 0; i < raps; i++) {

            //Resets the picked value
            for (int k = 0; k < v1.size(); k++) {
                v1.elementAt(k).picked = false;
            }

            //Pick two members to crossover
            index1 = pick(v1);
            index2 = pick(v1);

            System.out.println("Crossover is taking place on "
                    + "chromosomes " + index1 + " and " + index2);
            first = second = "";

            //Convert the bits into strings
            for (int j = 0; j < numVar; j++) {
                first += Integer.toString(v1.elementAt(index1).bits[j]);
                second += Integer.toString(v1.elementAt(index2).bits[j]);
            }

            Random rand = new Random();
            breakpoint = numVar - 1 - rand.nextInt(numVar - 1);
            System.out.println("Breakpoint of this crossover is " + breakpoint);

            //Break the strings into substrings according to the random breakpoint
            first_a = first.substring(0, breakpoint);
            first_b = first.substring(breakpoint);
            second_a = second.substring(0, breakpoint);
            second_b = second.substring(breakpoint);

            //Crossover the substrings
            first = first_a + second_b;
            second = second_a + first_b;

            System.out.println("Cross over is completed.");

            for (int k = 0; k < numVar; k++) {
                v1.elementAt(index1).tempbits[k] = Character.getNumericValue(first.charAt(k));
                v1.elementAt(index2).tempbits[k] = Character.getNumericValue(second.charAt(k));
            }
        }

        //tempbits is used to store the results of crossover, but do not update 
        //the current population until all crossovers are done, then copy content
        //of tempbits back to bits. -1 indicates that the member did not crossover
        //with others
        for (int i = 0; i < v1.size(); i++) {
            if (v1.elementAt(i).tempbits[0] != -1) {
                for (int j = 0; j < numVar; j++) {
                    v1.elementAt(i).bits[j] = v1.elementAt(i).tempbits[j];

                    //When copyings are done, reset tempbits to -1's
                    v1.elementAt(i).tempbits[j] = -1;
                }
            }
        }
    }

    //Returns the index of the chromosome that has been chosen for crossover
    public int pick(Vector<Candidate> vec) {
        double range = 0.0;
        int index = 0;
        boolean done = false;
        Random rand = new Random();

        do {
            //Randomly generates a number from 0 to 1
            range = rand.nextDouble();

            //Checks this number falls in which range
            for (int i = 0; i < vec.size(); i++) {
                if (range > vec.elementAt(i).lowerRange && range <= vec.elementAt(i).upperRange) {
                    index = i;
                }
            }

            //Makes sure the member does not crossover with itself
            if (!vec.elementAt(index).picked) {
                done = true;
                vec.elementAt(index).picked = true;
            }
        } while (!done);

        System.out.println("A random number " + range + " is picked.");

        return index;
    }

    //Randomly mutates a random bit of a random member of the current population
    public void mutation(int numVar, Vector<Candidate> vec) {

        Random rand = new Random();

        int chance = rand.nextInt(2);

        //50% chance of mutation happening
        if (chance == 1) {
            //Randomly select one member of the population
            int position = rand.nextInt(vec.size());

            //Randomly flip any bit of this chromosome
            int index = rand.nextInt(numVar);

            System.out.println("Mutation is happening on chromosome " + position);
            System.out.println("Changing bit " + index + " of this chromosome.");
            if (vec.elementAt(position).bits[index] == 1) {
                vec.elementAt(position).bits[index] = 0;
            } else {
                vec.elementAt(position).bits[index] = 1;
            }
        }
    }
}
